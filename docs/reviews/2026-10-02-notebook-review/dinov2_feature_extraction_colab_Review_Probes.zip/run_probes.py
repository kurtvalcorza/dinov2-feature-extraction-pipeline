"""Review probes for tutorials/dinov2_feature_extraction_colab.ipynb (row 22, review only).

Executes the committed notebook's code cells in order in one namespace (CPU, install skipped via
DIMER_NOTEBOOK_CI_PREINSTALLED=1 in an interpreter that already holds the exact pins), then:
  AL  - the documented optional experiment: TRAINABLE_BLOCKS = 1, re-run cells 19 -> 21 -> 23
  BYOD - USE_BYOD = True, 're-run from that cell' (13 -> 23) after the default run, EPOCHS = 1 (labelled)
  NEG  - incompatible BYOD inputs through the cell-13 code path
Usage: python run_probes.py <notebook> <workdir> <results.json>
Results are appended to results.json as soon as each probe finishes (write-immediately).
"""
import contextlib
import copy
import io
import json
import os
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

if len(sys.argv) > 1 and sys.argv[1] == '--static':
    # Static block: python run_probes.py --static <repo_root> <results.json> <source_manifest.json>
    import hashlib
    import re
    import subprocess
    root, out, man = Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
    nbp = root / 'tutorials/dinov2_feature_extraction_colab.ipynb'
    nbj = json.loads(nbp.read_text(encoding='utf-8'))
    md_all = '\n'.join(''.join(c['source']) for c in nbj['cells'] if c['cell_type'] == 'markdown')
    code_all = '\n'.join(''.join(c['source']) for c in nbj['cells'] if c['cell_type'] == 'code')
    compiled = []
    for i, c in enumerate(nbj['cells']):
        if c['cell_type'] == 'code':
            try:
                compile(''.join(c['source']), f'cell{i}', 'exec')
                compiled.append(True)
            except SyntaxError:
                compiled.append(False)
    markers = {k: bool(re.search(p, md_all, re.I)) for k, p in {
        'how_to_use': r'how to use this notebook', 'roadmap': r'roadmap', 'glossary': r'glossary',
        'audience': r'intended (learner|audience)|who this notebook is for', 'predict_prompt': r'\bpredict\b.*before',
        'check_your_reasoning': r'check your reasoning|sample answer', 'troubleshooting': r'troubleshoot',
        'conclusion_template': r'conclusion (template|scaffold)', 'infrastructure_label': r'infrastructure',
        'what_to_notice': r'what to notice', 'look_for': r'look for'}.items()}
    static = {
        'notebook_blob': subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD:tutorials/dinov2_feature_extraction_colab.ipynb'], capture_output=True, text=True).stdout.strip(),
        'head': subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip(),
        'nbformat': [nbj['nbformat'], nbj['nbformat_minor']], 'cells': len(nbj['cells']),
        'code_cells': len(compiled), 'code_cells_compile': all(compiled), 'metadata_dimer': nbj['metadata'].get('dimer'),
        'cellView_form_cells': [i for i, c in enumerate(nbj['cells']) if c.get('metadata', {}).get('cellView') == 'form'],
        'pip_install_in_kernel': "'-m', 'pip', 'install'" in code_all, 'uses_uv': 'uv venv' in code_all or "'uv'" in code_all,
        'restart_instruction_in_code': 'Restart the runtime' in code_all,
        'double_brace_leak_in_markdown': re.findall(r'`[^`]*\{\{[^`]*`', md_all),
        'guided_markers': markers,
        'carried_lines': {nbj['cells'][i]['metadata']['dimer']['embedded_module']: len(''.join(nbj['cells'][i]['source']).splitlines()) for i in range(len(nbj['cells'])) if nbj['cells'][i].get('metadata', {}).get('dimer', {}).get('embedded_module')},
        'outputs_persisted': any(c.get('outputs') for c in nbj['cells'] if c['cell_type'] == 'code'),
        'upload_location_field': 'BYOD_PATH' in code_all or 'BYOD_ZIP_PATH' in code_all,
        'readme_says_no_metric_helper': 'There is no label, no score and no metric helper' in (root / 'README.md').read_text(encoding='utf-8'),
    }
    res = json.loads(out.read_text(encoding='utf-8')) if out.exists() else {}
    res['static'] = static
    out.write_text(json.dumps(res, indent=1, default=str), encoding='utf-8')
    files = ['tutorials/dinov2_feature_extraction_colab.ipynb', 'tools/build_notebook.py', 'tools/notebook_template.py',
             'tools/validate_release_assets.py', 'src/dinov2_feature_extraction_pipeline/pipeline.py',
             'src/dinov2_feature_extraction_pipeline/samples.py', 'src/dinov2_feature_extraction_pipeline/metrics.py',
             'README.md', 'STATUS.md', 'MODEL_CARD.md', 'tutorials/README.md', 'docs/release-verification.md', 'docs/WEIGHTS.md', 'pyproject.toml']
    man.write_text(json.dumps({'repository': 'kurtvalcorza/dinov2-feature-extraction-pipeline', 'revision': static['head'],
                               'sha256': {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files}}, indent=1), encoding='utf-8')
    print(json.dumps(static, indent=1, default=str)[:4000])
    sys.exit(0)

NB, WORK, OUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
RESULTS = {'notebook': str(NB), 'env': {}, 'default': {}, 'active_learning': {}, 'byod': {}, 'byod_negative': {}}
T_START = time.perf_counter()


def save():
    OUT.write_text(json.dumps(RESULTS, indent=1, default=str), encoding='utf-8')


nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
CODE = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}

# google.colab shim: files.upload() returns whatever UPLOAD holds
UPLOAD = {}
colab = types.ModuleType('google.colab')
colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
google = types.ModuleType('google')
google.colab = colab
sys.modules['google'] = google
sys.modules['google.colab'] = colab


def set_field(src, name, value):
    lines = src.splitlines()
    hit = [k for k, line in enumerate(lines) if line.startswith(name + ' = ')]
    if len(hit) != 1:
        raise RuntimeError(f'form field {name} not found exactly once')
    k = hit[0]
    comment = lines[k].split('#', 1)[1] if '#' in lines[k] else ''
    lines[k] = f'{name} = {value!r}  #{comment}'
    return '\n'.join(lines)


def run(ns, idx, src=None, tail=4000):
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(src if src is not None else CODE[idx], f'<cell {idx}>', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'[:1500]
            buf.write('\n' + traceback.format_exc()[-1500:])
    return {'cell': idx, 'seconds': round(time.perf_counter() - t0, 1), 'error': err, 'stdout_tail': buf.getvalue()[-tail:]}


import importlib.metadata as md  # noqa: E402
import platform  # noqa: E402
RESULTS['env'] = {'python': platform.python_version(), 'platform': platform.platform(),
                  **{d: md.version(d) for d in ('torch', 'torchvision', 'timm', 'huggingface-hub', 'safetensors', 'numpy', 'pillow')},
                  'interpreter': sys.executable, 'workdir': str(WORK), 'hf_home': os.environ.get('HF_HOME')}
save()

if os.environ.get('PROBE_MODE') == 'byod_neg':
    # Cheap re-run after the 20-min cap: carried modules only (no model), cached corpus, BYOD negatives via cell 13.
    RESULTS = json.loads(OUT.read_text(encoding='utf-8'))
    ns = {'__name__': '__main__', 'os': os}
    for idx in (5, 7, 9):
        r = run(ns, idx)
        if r['error']:
            raise SystemExit(r['error'])
    ns_after_default = dict(ns)
    ns_after_default['corpus'] = ns['read_corpus'](ns['fetch_corpus'](cache_dir='weights/inat-birds'))
    RESULTS['default'].setdefault('ok', True)
    d = {'ok': True}
    post_default = None
    SKIP_MODEL = True
else:
    SKIP_MODEL = False
# ---------------- default path (Run all order) ----------------
if not SKIP_MODEL:
    ns = {'__name__': '__main__'}
    steps = []
    hook = {}
    for idx in sorted(CODE):
        r = run(ns, idx)
        steps.append(r)
        RESULTS['default']['cells'] = steps
        save()
        if r['error']:
            break
        if idx == 17:  # capture the probe's own predictions on the six images Section 9 shows
            show = ns['test_records'][:6]
            hook = ns['pipe'].classify([x['image'] for x in show])
    d = RESULTS['default']
    d['ok'] = all(not s['error'] for s in steps) and len(steps) == len(CODE)
    if d['ok']:
        d['comparison'] = ns['comparison']
        d['adapt_history'] = [{'epoch': h['epoch'], 'val': h['val'], 'train_loss': h['train_loss']} for h in ns['adapt_result']['history']]
        d['selected_policy'] = ns['adapt_result']['policy']
        d['best_epoch'] = ns['adapt_result']['best_epoch']
        d['probe_validation'] = ns['probe_result']['history'][0]['val']
        d['reload_parity'] = ns['parity']
        d['split_counts'] = {k: len(v) for k, v in ns['splits'].items()}
        d['observer_overlap'] = ns['overlap']
        d['digests'] = {k: m['digest'][:16] for k, m in ns['dataset_manifests'].items()}
        d['outputs'] = sorted(os.listdir('outputs'))
        # Section 9 says the frozen column is "recomputed from the probe's stored head"; the code retrains a probe
        d['section9_frozen_column'] = {
            'cell17_probe_labels': hook.get('labels'), 'cell23_before_labels': ns['before']['labels'],
            'labels_identical': hook.get('labels') == ns['before']['labels'],
            'probabilities_identical': hook.get('probabilities') == ns['before']['probabilities'],
            'max_abs_prob_diff': max(abs(a - b) for ra, rb in zip(hook['probabilities'], ns['before']['probabilities']) for a, b in zip(ra, rb)),
        }
    save()
    post_default = copy.deepcopy(ns['pipe']) if d['ok'] else None
    ns_after_default = dict(ns)

    # ---------------- active learning: documented experiment, TRAINABLE_BLOCKS = 1 ----------------
    if d['ok']:
        al = RESULTS['active_learning']
        al['instruction'] = "Interpretation cell: 'set TRAINABLE_BLOCKS = 1 or 4 and watch the selection' (no rerun scope given); re-ran cells 19 -> 21 -> 23"
        src19 = set_field(CODE[19], 'TRAINABLE_BLOCKS', 1)
        al['cells'] = [run(ns, 19, src19)]
        save()
        if not al['cells'][0]['error']:
            al['rerun_epoch0_val'] = ns['adapt_result']['history'][0]['val']
            al['pristine_probe_val'] = d['probe_validation']
            al['epoch0_matches_pristine_probe'] = al['rerun_epoch0_val'] == d['probe_validation']
            al['history'] = [{'epoch': h['epoch'], 'val': h['val']} for h in ns['adapt_result']['history']]
            al['selected'] = ns['adapt_result']['policy']
            al['cells'].append(run(ns, 21))
            save()
            if not al['cells'][-1]['error']:
                al['comparison'] = ns['comparison']
            al['cells'].append(run(ns, 23))
            al['cell23_error'] = al['cells'][-1]['error']
            save()
        # reference: what the experiment means from a fresh base (cells 11 -> 23 order, only the field changed)
        if time.perf_counter() - T_START < 900:
            ref = {k: v for k, v in ns_after_default.items()}
            ref['pipe'] = ref['DINOv2FeatureExtractionPipeline'].from_pretrained(weights_dir=ref['WEIGHTS_DIR'])
            # frozen policy on the fresh base, as cell 17 would produce it
            r17 = run(ref, 17)
            r19 = run(ref, 19, src19)
            r21 = run(ref, 21)
            al['fresh_reference'] = {'cells': [r17, r19, r21],
                                     'epoch0_val': ref['adapt_result']['history'][0]['val'] if not r19['error'] else None,
                                     'history': [{'epoch': h['epoch'], 'val': h['val']} for h in ref['adapt_result']['history']] if not r19['error'] else None,
                                     'selected': ref['adapt_result']['policy'] if not r19['error'] else None,
                                     'comparison': ref.get('comparison') if not r21['error'] else None}
            save()

# ---------------- BYOD: positive (re-run from cell 13 after the default run) ----------------
corpus = ns_after_default.get('corpus') if d['ok'] else None


def make_zip(path, rows, files, extra=None, csv_text=None):
    with zipfile.ZipFile(path, 'w') as z:
        if csv_text is None:
            csv_text = 'id,file,label\n' + ''.join(f'{a},{b},{c}\n' for a, b, c in rows)
        if csv_text is not False:
            z.writestr('labels.csv', csv_text)
        for name, data in files.items():
            z.writestr(name, data)
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return path.read_bytes()


if corpus is not None:
    def jpeg(img):
        b = io.BytesIO()
        img.save(b, format='JPEG', quality=90)
        return b.getvalue()

    chosen = {}
    for rec in corpus:
        chosen.setdefault(rec['label'], [])
        if len(chosen[rec['label']]) < 15:
            chosen[rec['label']].append(rec)
    labels4 = sorted(chosen)[:4]
    rows, files = [], {}
    for lab in labels4:
        for j, rec in enumerate(chosen[lab]):
            fn = f'{lab}_{j:02d}.jpg'
            rows.append((f'{lab}-{j:02d}', fn, lab))
            files[fn] = jpeg(rec['image'])
    Path('byod').mkdir(exist_ok=True)
    payload = make_zip(Path('byod/birds60.zip'), rows, files)
    b = RESULTS['byod'] if not SKIP_MODEL else {}
    b['dataset'] = {'images': len(rows), 'classes': labels4, 'per_class': 15, 'source': 'drawn from the pinned sample corpus, re-encoded JPEG (stand-in user data)'}
    b['instruction'] = "Cell 0: 'set USE_BYOD = True in Section 4 and re-run from that cell'; ran 13 -> 15 -> 17 -> 19 -> 21 -> 23 after the default run, EPOCHS = 1 (labelled deviation for time)"
    bns = dict(ns_after_default)
    bns['pipe'] = copy.deepcopy(post_default) if post_default is not None else None
    UPLOAD.clear()
    UPLOAD['birds60.zip'] = payload
    seq = [] if SKIP_MODEL else [(13, set_field(CODE[13], 'USE_BYOD', True)), (15, None), (17, None),
           (19, set_field(CODE[19], 'EPOCHS', 1)), (21, None), (23, None)]
    b['cells'] = []
    for idx, src in seq:
        r = run(bns, idx, src)
        b['cells'].append(r)
        save()
        if r['error']:
            break
    if not SKIP_MODEL and 'baseline_knn' in bns and not b['cells'][2]['error']:
        b['knn_on_post_default_backbone'] = round(bns['baseline_knn']['accuracy'], 4)
        fresh = bns['DINOv2FeatureExtractionPipeline'].from_pretrained(weights_dir=bns['WEIGHTS_DIR'])
        b['knn_on_fresh_backbone'] = round(fresh.knn_baseline(bns['train_records'], bns['test_records'], k=5)['accuracy'], 4)
        b['split_counts'] = {k: len(v) for k, v in bns['splits'].items()}
    b['selected'] = bns.get('adapt_result', {}).get('policy') if 'adapt_result' in bns else None
    if not SKIP_MODEL:
        b['outputs_after'] = sorted(os.listdir('outputs'))
    save()

    # ---------------- BYOD negatives through the cell-13 code path ----------------
    neg = RESULTS['byod_negative']
    small_rows, small_files = rows[:20] + rows[15:35], {}
    small_rows = [r for r in rows if r[2] in labels4[:2]][:40]
    small_files = {r[1]: files[r[1]] for r in small_rows}
    cases = {
        'in-contract 40 images, 2 classes x 20 (Prerequisites: a dataset needs 8..20,000 records)': (small_rows, small_files, None, None),
        'zip without labels.csv': (rows[:10], {r[1]: files[r[1]] for r in rows[:10]}, None, False),
        'labels.csv missing the label column': (None, {r[1]: files[r[1]] for r in rows[:10]}, None, 'id,file,species\n' + ''.join(f'{a},{b2},{c}\n' for a, b2, c in rows[:10])),
        'row names a file not in the zip': (rows[:12] + [('ghost-1', 'ghost.jpg', labels4[0])], {r[1]: files[r[1]] for r in rows[:12]}, None, None),
        'a text file named .jpg': (rows[:12], {**{r[1]: files[r[1]] for r in rows[:12]}, rows[0][1]: b'not an image'}, None, None),
        'single class': ([r for r in rows if r[2] == labels4[0]], {r[1]: files[r[1]] for r in rows if r[2] == labels4[0]}, None, None),
        'two members with the same basename in different folders': (rows[:12], {r[1]: files[r[1]] for r in rows[:12]}, {'other/' + rows[0][1]: files[rows[20][1]]}, None),
    }
    for name, (r_, f_, extra, csv_text) in cases.items():
        nns = dict(ns_after_default)
        UPLOAD.clear()
        UPLOAD['case.zip'] = make_zip(Path('byod/case.zip'), r_ or [], f_, extra, csv_text)
        res = run(nns, 13, set_field(CODE[13], 'USE_BYOD', True), tail=600)
        entry = {'error': res['error'], 'seconds': res['seconds']}
        if not res['error']:
            entry['accepted_splits'] = {k: len(v) for k, v in nns['splits'].items()}
            if 'same basename' in name:
                imgs = [rr for rr in nns['records'] if rr['id'] == rows[0][0]]
                from PIL import Image as _I, ImageChops  # noqa: E402
                own = _I.open(io.BytesIO(files[rows[0][1]])).convert('RGB')
                entry['first_row_image_equals_its_own_file'] = bool(imgs) and imgs[0]['image'].size == own.size and ImageChops.difference(imgs[0]['image'], own).getbbox() is None
        neg[name] = entry
        save()

RESULTS['wall_seconds'] = round(time.perf_counter() - T_START, 1)
save()
print('done', RESULTS['wall_seconds'])
